import Foundation
import CoreData
func model(_ version: Int) -> NSManagedObjectModel {
    let result = NSManagedObjectModel()
    let entity = NSEntityDescription(); entity.name = "AuditRecord"; entity.managedObjectClassName = "NSManagedObject"
    let text = NSAttributeDescription(); text.name = "text"; text.attributeType = .stringAttributeType; text.isOptional = true
    entity.properties = [text]
    if version == 2 { let value = NSAttributeDescription(); value.name = "newOptionalValue"; value.attributeType = .stringAttributeType; value.isOptional = true; entity.properties.append(value) }
    result.entities = [entity]; return result
}
let url = FileManager.default.temporaryDirectory.appendingPathComponent("holo-model-probe-\(UUID()).sqlite")
func container(_ version: Int) throws -> NSPersistentContainer {
    let c = NSPersistentContainer(name: "Audit", managedObjectModel: model(version))
    let d = NSPersistentStoreDescription(url: url)
    d.shouldAddStoreAsynchronously = false
    d.setOption(true as NSNumber, forKey: NSMigratePersistentStoresAutomaticallyOption)
    d.setOption(true as NSNumber, forKey: NSInferMappingModelAutomaticallyOption)
    d.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)
    d.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
    c.persistentStoreDescriptions = [d]
    var error: Error?; c.loadPersistentStores { _, e in error = e }
    if let error { throw error }; return c
}
let c1 = try container(1)
let record = NSEntityDescription.insertNewObject(forEntityName: "AuditRecord", into: c1.viewContext); record.setValue("synthetic", forKey: "text"); try c1.viewContext.save()
for s in c1.persistentStoreCoordinator.persistentStores { try c1.persistentStoreCoordinator.remove(s) }
do { let c2 = try container(2); print("MIGRATION_OK:", try c2.viewContext.count(for: NSFetchRequest(entityName: "AuditRecord"))) }
catch { print("MIGRATION_FAILED:", error as NSError) }
