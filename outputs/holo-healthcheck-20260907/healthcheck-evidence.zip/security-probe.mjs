// 仅使用内存数据库与虚构数据；不访问生产接口，不调用模型。
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createApp } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/app.js';
import { createDatabase } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/db/database.js';
import { createCloudAnalysisTaskStore } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/agent/cloudAnalysisTaskStore.js';

const database = createDatabase({ dbPath: ':memory:' });
const key = randomBytes(32).toString('base64');
const store = createCloudAnalysisTaskStore(database.db, { encryptionKey: key });
const app = createApp({
  database, auth: { enforceAppAttest: true },
  subscription: { appleVerificationMode: 'disabled' },
  aiCallLogs: { enabled: false }, runtimeEnvironment: 'test',
  cloudAnalysisEncryptionKey: key, cloudAnalysisTaskStore: store,
  cloudAnalysisExecutor: { run: async () => 'queued' },
});
const headers = { 'content-type': 'application/json', 'x-holo-device-id': 'synthetic-owner' };
const without = await app.request('/v1/subscription/status');
const spoofed = await app.request('/v1/subscription/status', { headers });
assert.equal(without.status, 401);
assert.equal(spoofed.status, 200);
console.log('CONFIRMED: enforceAppAttest=true rejects no ID, accepts self-asserted ID without assertion or session.');

const receipt = await app.request('/v1/subscription/sync', {
  method: 'POST', headers, body: JSON.stringify({ signedTransactionInfo: 'synthetic-jws' }),
});
assert.equal(receipt.status, 503);
assert.equal((await receipt.json()).error.code, 'SUBSCRIPTION_VERIFICATION_UNAVAILABLE');
console.log('CONFIRMED: production verification mode rejects all receipts with 503 before verification.');

const task = store.create({ deviceId: 'synthetic-owner', question: 'synthetic question' });
store.attachSnapshot({ id: task.id, snapshot: '{}' });
store.transition(task.id, 'running');
store.complete({ id: task.id, result: JSON.stringify({ title: 'synthetic private result' }) });
const other = await app.request(`/v1/ai/agent/cloud/${task.id}`, { headers: { ...headers, 'x-holo-device-id': 'synthetic-other' } });
const attacker = await app.request(`/v1/ai/agent/cloud/${task.id}`, { headers });
assert.equal(other.status, 404);
assert.equal(attacker.status, 200);
assert.equal((await attacker.json()).result.title, 'synthetic private result');
console.log('CONFIRMED: knowing task ID and copying owner device ID retrieves result without proof of identity.');
for (const file of ['src/subscription/appleReceiptVerifier.js', 'src/app.js', 'src/auth/appleRevokeService.js']) {
  console.log(file, createHash('sha256').update(readFileSync('/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/' + file)).digest('hex'));
}
database.close();
