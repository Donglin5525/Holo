// 合成任务 + 内存库 + 假模型；验证云端关键契约，不触发外部调用。
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { createDatabase } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/db/database.js';
import { createCloudAnalysisTaskStore } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/agent/cloudAnalysisTaskStore.js';
import { createCloudAnalysisExecutor } from '/Users/tangyuxuan/Desktop/Claude/HOLO/HoloBackend/src/agent/cloudAnalysisExecutor.js';
const database = createDatabase({ dbPath: ':memory:' });
const store = createCloudAnalysisTaskStore(database.db, { encryptionKey: randomBytes(32).toString('base64') });
let reservations = 0;
let calls = 0;
let cancelOnFirstCall = null;
const provider = { async complete() {
  calls++;
  if (cancelOnFirstCall && calls === 1) store.cancel(cancelOnFirstCall);
  const output = cancelOnFirstCall && calls === 1
    ? { status: 'need_more_analysis', reasoning: 'synthetic', toolRequests: [], claims: [], warnings: [] }
    : { status: 'final_claims', reasoning: 'synthetic', toolRequests: [], claims: [{ summary: '本月支出99999元', displayText: '本月支出99999元', evidenceIDs: [] }], warnings: [] };
  return { choices: [{ message: { content: JSON.stringify(output) } }] };
} };
const executor = createCloudAnalysisExecutor({ taskStore: store, providers: new Map([['fake', provider]]), route: {provider:'fake',model:'fake'}, providerRetries: 1, maxRounds: 3, log: () => {},
  quotaLedger: { reserve() { reservations++; return {allowed:false}; }, commit() {}, release() {} },
  entitlementResolver: { resolve: () => ({ usageSubjectId: 'synthetic', tier: 'free' }) },
});
function newTask() {
  const task = store.create({deviceId:'synthetic',question:'合成测试'});
  store.attachSnapshot({id:task.id,snapshot:JSON.stringify({version:1,datasets:{}})});
  return task;
}
const task = newTask();
assert.equal(await executor.run(task.id), 'completed');
assert.equal(reservations, 0);
const result = JSON.parse(store.getDecrypted(task.id, ['result']).result);
assert.equal(result.claims[0].displayText, '本月支出99999元');
assert.equal(result.evidence.length, 0);
console.log('CONFIRMED: deep_analysis succeeds with zero quota checks and accepts an unsupported factual claim with no evidence.');
calls = 0;
const cancelled = newTask(); cancelOnFirstCall = cancelled.id;
const status = await executor.run(cancelled.id);
assert.equal(store.get(cancelled.id), null);
assert.equal(calls, 2);
assert.equal(status, 'completed');
console.log('CONFIRMED: after cancellation deletes task, executor still makes another model call and reports completed.');
database.close();
